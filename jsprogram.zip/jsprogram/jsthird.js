let age = 14;
if(age >=14)
{
    alert("you can vote!");
}