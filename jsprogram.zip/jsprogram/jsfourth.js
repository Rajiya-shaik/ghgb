let age = 12;
if(age >=14){
    alert("you can vote!");
}else
{
    alert("you cannot vote!");
}